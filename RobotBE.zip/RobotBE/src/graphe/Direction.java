package graphe;

public enum Direction {
	TOUT_DROIT,
	GAUCHE,
	DROITE;
}
