package moteur;

public interface Moteur {

	public void setSpeed(int val);
	
	public void arreter();
	
	public void tournerAGauche();
	
	public void tournerADroite();
}
